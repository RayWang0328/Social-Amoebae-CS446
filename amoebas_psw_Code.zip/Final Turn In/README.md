# Social-Amoebae-CS446

This is the project for Social Amoebaes by Ray Wang, Emmett Smith, and MJ
Pennington. 

amoeba_psw_Clustering_Validation:
This code just needs to be run again to show the clustering validation that
is produced for the manuscript.

amoeba_psw_Ex1_Infection_Reproduction_Rate_1:
This is an experiment is where the rate of reproduction is 1.0, meaning 
there is no reproduction for infection. It also generates graphs to explore 
how this affects infection across generations.

amoeba_psw_Ex2_Infection_Reproduction_Rate_12:
This is an experiment is where the rate of reproduction is 1.2, meaning 
there is 20% growth for infection, and generates graphs to explore 
how this affects infection across generations.

amoeba_psw_Ex3_Infection_Reproduction_Rate_14:
This is an experiment is where the rate of reproduction is 1.4, meaning 
there is 40% growth for infection, and generates graphs to explore 
how this affects infection across generations.

amoeba_psw_Ex4_Infection_Reproduction_Rate_16:
This is an experiment is where the rate of reproduction is 1.6, meaning 
there is 60% growth for infection, and generates graphs to explore 
how this affects infection across generations.


amoeba_psw_Ex5_Infection_Reproduction_Rate_18:
This is an experiment is where the rate of reproduction is 1.8, meaning 
there is 80% growth for infection, and generates graphs to explore 
how this affects infection across generations.

amoeba_psw_Ex6_Infection_Reproduction_Rate_2:
This is an experiment is where the rate of reproduction is 2.0, meaning 
there is 100% growth for infection, and generates graphs to explore 
how this affects infection across generations.

amoeba_psw_final_working.m:
This is a file which has the final working section of our code which can be
changed and modified to run different experiments.

amoeba_psw_Horizontal_Infection_Validation:
This code can be run again to show the horizontal infection validation that
is produced for the manuscript.

amoeba_psw_Reproduction_and_infection_transmission_simulation1_043024:
This code can be run again to show the spore dispersal validation that
is produced for the manuscript.

amoeba_psw_Vertical_Infection_Validation:
This code can be run again to show the vertical infection validation that
is produced for the manuscript.
